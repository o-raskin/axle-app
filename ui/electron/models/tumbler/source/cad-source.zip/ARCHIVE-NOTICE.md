# Attribution and rights for this CAD source archive

This is a lossless source container, not an Axle-owned vehicle design. The original Studio recreation was published by 포기남 (Fogeyman) at https://fogeyman.tistory.com/1770 with CC BY-NC 4.0 terms. Archive packing does not change original CAD bytes or eliminate attribution, noncommercial restrictions or missing underlying permissions.
License: https://creativecommons.org/licenses/by-nc/4.0/legalcode.en
LDraw parts retain their individual author/license/history headers and full agreements in ldraw/. Some supplied or embedded Studio custom geometry has no separate confirmed license. LEGO/DC/Warner Bros. design and trademark rights are not granted by this container. Axle is independent and not sponsored, authorized or endorsed by those parties.

The following retained notices are copied from the accompanying model package. Repository-relative Markdown links below refer to that package; the original publication and license URLs also appear in this archive for standalone attribution.

# Tumbler model asset licenses

The third-party model sources and geometry derived from them have their own
licenses. They are **not covered by this repository's Apache-2.0 license**.
Ownership remains with the respective creators and other rights holders.
This notice records available evidence; it is not a new permission from them.
See [RIGHTS.md](RIGHTS.md) for unresolved rights and distribution limits.

## Set assembly publication

- Creator: **포기남 (Fogeyman)**.
- Work: Studio recreation of LEGO Technic **42239 Batmobile Tumbler**.
- Published: **2026-08-12**.
- Original page: <https://fogeyman.tistory.com/1770>.
- Original attachments: `42239.io`, `7655.part`, `7683.part`, and
  `103479c01-3.part`.
- License displayed on that source page:
  [Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0)](https://creativecommons.org/licenses/by-nc/4.0/).
- Full license terms:
  <https://creativecommons.org/licenses/by-nc/4.0/legalcode>.

The page's `rel="license"` link and Creative Commons metadata identify CC BY-NC
4.0. Axle relies on this published notice for the author's licensable assembly
contribution, not on a private permission or a claim that public downloads are
automatically unrestricted. Evidence and its limits are recorded in
[source/LICENSE-EVIDENCE.md](source/LICENSE-EVIDENCE.md).

Credit the creator, retain supplied notices and license links, and identify
changes. NonCommercial means the use is not primarily directed toward commercial
advantage or monetary compensation. **Commercial use requires permissions from
the relevant rights holders that cover that use.** A free download or an Apache
code license does not resolve this condition. The license excludes trademark
and patent rights and does not imply endorsement. See its
[legal code, sections 1(i), 2 and 3](https://creativecommons.org/licenses/by-nc/4.0/legalcode.en).

The generated Axle rendering asset retains material from this Studio assembly:
archive extraction, coordinate conversion, offline geometry conversion,
material adjustment, mesh optimization, animation rigging, and reconstructed
light-guide/graphic additions. Original assembly bytes are preserved. These
changes do not extinguish the original rights. Preserve this notice,
[RIGHTS.md](RIGHTS.md), and the generated part attributions with distributed
assets, including archives, GLB files and application packages.

## Supplied custom and embedded Studio geometry

The following names are transcribed from retained file headers, not inferred
ownership claims. The `custom/` and `ldraw/` paths are entries in
`source/cad-source.zip`, with original headers and library license texts retained
inside the lossless archive. None of these custom files contains a separate
`!LICENSE` header. A blank author field is **not** evidence of public-domain status.

| Files under the archive's `custom/` directory | Creator named in the retained header |
| --- | --- |
| `7101.dat`, `s/7101s01.dat`, `s/71682s03.dat` | Gerald Lasser [GeraldLasser] |
| `s/7101s02.dat` | Jens Brühl [jb70] |
| `103479c01-3.dat`, `69790.dat`, `7655.dat`, `7683.dat`, `bl_7973.dat` | Not identified |

These files were supplied in or extracted from the published Studio project.
The publication's CC notice does **not** independently establish that Fogeyman
owns or can license all embedded geometry. Do not label them as Axle-authored,
public domain, or LDraw-licensed without matching license evidence. Their
separate rights chain remains unverified; attribution cannot fill that gap.

## LDraw parts library

The model includes geometry originating from **The LDraw Parts Library**.
Additional library primitives may be incorporated to resolve model
dependencies. Preserve the original author and license headers in retained
LDraw source files and identify those files in the asset manifest.

LDraw library files retain the author, `!LICENSE`, and `!HISTORY` notices supplied
by their contributors. The file's actual notice determines its applicable
terms, including any mixed CC BY 2.0/4.0 contribution history; the library's
current contributor agreement also supports CC0. These permissions do not
relicense unverified Studio fallbacks or remove the separate assembly's
noncommercial condition. Per-file attribution is listed in
[generated/THIRD-PARTY-NOTICES.md](generated/THIRD-PARTY-NOTICES.md).

- Library: <https://library.ldraw.org/>.
- Attribution and reuse guidance:
  <https://www.ldraw.org/docs-main/licenses/legal-info.html>.
- Contributor agreement:
  <https://www.ldraw.org/article/349.html>.
- License links: <https://creativecommons.org/licenses/by/2.0/>,
  <https://creativecommons.org/licenses/by/4.0/>, and
  <https://creativecommons.org/publicdomain/zero/1.0/>.

## Reference material and trademarks

Original LEGO product photographs and instruction pages are not bundled as
image files. Some surface graphics were reconstructed from those references;
permission for the underlying markings has not been established by this record.
LEGO® is a trademark of the LEGO Group, which does not sponsor, authorize, or
endorse this project. Technic™ is also a LEGO Group trademark. Batman™,
Batmobile™ and related character/element rights involve DC and Warner Bros.
The [officially sanctioned Tumbler page](https://brucewaynex.com/pages/tumbler)
identifies DC rights in Batman and related elements and states Warner Bros.
sanction for its own replicas; that permission does not extend to Axle.
Axle does not claim ownership or an official license to the underlying LEGO/DC
vehicle design. No endorsement by the model author, LDraw, LEGO Group, DC or
Warner Bros. is recorded or implied.

LEGO's [Fair Play guidance](https://www.lego.com/en-us/legal/notices-and-policies/fair-play)
explains that a disclaimer does not cure improper trademark use. This notice
therefore identifies rights without claiming that a trademark symbol or fan
project status makes copying or distribution lawful.

## Warranty and requests

The CC license's [section 5](https://creativecommons.org/licenses/by-nc/4.0/legalcode.en#s5)
disclaims warranties, including title and non-infringement, to the extent allowed
by law. This project likewise provides no assurance that every underlying right
has been cleared. This notice does not waive third-party rights or limit any
mandatory legal rights.

Rights holders can send a correction or removal request through the repository
maintainer's GitHub contact or a repository issue, identifying the material,
claimed rights and requested action. Do not publish confidential evidence in
an issue. A request should be reviewed promptly; this contact route does not
replace formal legal procedures.

# Rights and distribution status

Reviewed against retained source files and primary-source notices on **2026-10-01**.
This is an evidence and attribution record, not legal clearance or a warranty.

## What belongs to whom

| Material | Attribution and status |
| --- | --- |
| Studio set assembly and published reconstruction | 포기남 (Fogeyman), [original publication](https://fogeyman.tistory.com/1770); publication states CC BY-NC 4.0. No direct permission beyond that notice is recorded. |
| Retained official LDraw parts/primitives | Individual contributors named in file headers, collectively The LDraw Parts Library. Apply each file's retained license and history; see [part notices](generated/THIRD-PARTY-NOTICES.md). |
| Custom and embedded Studio fallback meshes | Creator names where present are listed in [LICENSE.md](LICENSE.md); separate mesh-license evidence is missing. Blank headers do not transfer ownership. |
| Axle conversion/runtime scripts | Repository contributors, under the repository's Apache-2.0 code license. That license does not cover the imported assembly or embedded meshes. |
| Generated GLB, model previews, rig and source archives | Retain the applicable underlying rights and notices. Merging, compression, or conversion is not an ownership transfer. |
| Underlying set, branded vehicle appearance, names and markings | Relevant LEGO Group/DC/Warner Bros. rights remain separate; no grant for them is established by this repository. |

LEGO® is a trademark of the LEGO Group, which does not sponsor, authorize, or
endorse this project. Axle is also independent of DC, Warner Bros., Fogeyman and
LDraw contributors. Product names identify the vehicle being represented.
The [official set page](https://www.lego.com/en-us/product/batmobile-tumbler-42239)
identifies the represented product. The
[sanctioned Tumbler replica page](https://brucewaynex.com/pages/tumbler) identifies
DC rights in Batman/related elements and Warner Bros. approval for that separate
product. Neither page grants this repository a vehicle-design license.

## What this repository establishes

The author publication and local hashes are recorded in
[source/LICENSE-EVIDENCE.md](source/LICENSE-EVIDENCE.md) and
`source/provenance.json`. The assembly is treated as CC BY-NC 4.0 material;
its original bytes and the LDraw contributor notices are retained. Changes
are described in [LICENSE.md](LICENSE.md) and the generated part notices.
CAD/part paths in those records identify entries in `source/cad-source.zip`;
lossless packing retains their bytes and original headers rather than replacing
their licenses. Archive extraction restores those paths for inspection/editing.
LDraw's [legal guidance](https://www.ldraw.org/docs-main/licenses/legal-info.html)
and [contributor agreement](https://www.ldraw.org/article/349.html) describe the
library licenses; they do not prove a license for unidentified Studio meshes.

## What remains unresolved

The post's Creative Commons footer is evidence of the publisher's license
choice, not proof of ownership of everything inside its attachments. Some
custom files name different creators; others identify none. No separate
license or consent from those creators is recorded. No permission covering
the underlying LEGO/DC design, trademarks, or markings is recorded either.

The [CC BY-NC legal code](https://creativecommons.org/licenses/by-nc/4.0/legalcode.en)
licenses only rights the licensor can grant. Its noncommercial condition
depends on the use, not simply whether the app costs money. A public GitHub
repository makes material available to others; the same unresolved rights
still matter there. Apache-licensed source code does not make its bundled
CC BY-NC asset suitable for unrestricted commercial reuse.

Attribution, a disclaimer, a trademark symbol and noncommercial intent cannot
create missing permission. LEGO's [Fair Play guidance](https://www.lego.com/en-us/legal/notices-and-policies/fair-play)
expressly says a disclaimer cannot repair improper trademark use. These
documents reduce incorrect ownership/affiliation claims and preserve known
terms; they cannot guarantee protection from a complaint or lawsuit.

## Distribution practice

Keep [LICENSE.md](LICENSE.md), this record, source provenance, and generated
part notices with model distributions, including compact source bundles and
app packages. Preserve original license/author/history lines inside source
bundles and identify subsequent modifications. Do not claim that the whole
repository's assets are Apache-2.0 or commercially cleared.

For wider or commercial distribution, obtain the relevant missing permissions
or replace the affected geometry/design with independently cleared material.
The right to retain/use this asset under the available evidence should be
reviewed for the intended jurisdiction and use if release certainty is needed.
Rights-holder correction/removal requests should be routed to the repository
maintainer as described in [LICENSE.md](LICENSE.md).

# Source license evidence

Checked on **2026-10-01** at <https://fogeyman.tistory.com/1770>.

The post is attributed to **포기남 (Fogeyman)**, dated **2026-08-12**, and offers
`42239.io`, `7655.part`, `7683.part`, and `103479c01-3.part` as public file
attachments. The same post displays a Creative Commons footer with
`rel="license"` linking to
<https://creativecommons.org/licenses/by-nc/4.0/deed.ko>. Its metadata has
`data-ccl-type="6"` and `data-ccl-derive="1"`; its RDF license block identifies
Attribution, permitted derivative works, and prohibited commercial use.

The `.io` archive and extracted assembly `.mpd` retain their original bytes.
The original three supplied custom files also retain their bytes; embedded
fallback files were extracted and their inherited color codes normalized,
as recorded in `provenance.json`. The assembly's `Author:` field is blank.
Axle attributes the published reconstruction to its publisher rather than
treating a blank field as public-domain authorship.

The CAD/dependency tree is retained losslessly inside `cad-source.zip`; source
paths in this record and provenance identify its entries. Packing/extraction
does not remove or change original author, license or history headers.

The post was rechecked directly over HTTPS; its author metadata, publication
timestamp, attachment filenames and CC link remain present. The retrieved HTML
had SHA-256 `1a07ff71b6e0bb0e3bfd5c2e04cc5ff8351fc16e23dfb3dae7c6fb6156b00225`.
This hash identifies that retrieval, not an immutable webpage: attachment URLs
and page metadata can change. The full page and its photographs are not included
in this repository.

## Evidence limits

The CC notice is attached to the publication. It does not separately identify
an author/license for every attached mesh or prove that the publisher owns all
underlying rights. No separate private permission is recorded. The custom files
contain no `!LICENSE` lines. `7101.dat`, `s/7101s01.dat` and `s/71682s03.dat` name
**Gerald Lasser [GeraldLasser]**; `s/7101s02.dat` names **Jens Brühl [jb70]**.
The other custom files have blank authors. A copied Studio header or a matching
part number does not establish that exact geometry's LDraw license.

Official LDraw files separately retain contributor names, licenses and history.
Do not replace those terms with the source page's CC BY-NC notice, and do not
infer a permissive license for a fallback from the library's general policy.
No grant of LEGO/DC vehicle-design or trademark rights was found in this source
record. See [../RIGHTS.md](../RIGHTS.md) for the remaining distribution limits.

See [../LICENSE.md](../LICENSE.md) for retained model notices and separate
LDraw library attribution. This is a brief evidence record, not a copy of the
source webpage or its images.

## Original-source provenance (container metadata omitted)

```json
{
  "set": "42239",
  "sourceAuthor": "포기남 (Fogeyman)",
  "sourcePage": "https://fogeyman.tistory.com/1770",
  "sourcePublished": "2026-08-12",
  "retrieved": "2026-10-01",
  "assemblyLicense": "CC-BY-NC-4.0",
  "assemblyLicenseUrl": "https://creativecommons.org/licenses/by-nc/4.0/",
  "studioBrickInstances": 712,
  "officialSetPieces": 719,
  "knownSourceApproximation": "The source creator used an earlier integrated-hub CAD revision as a surrogate. Do not claim an independently verified complete719-element digital twin.",
  "files": [
    {
      "path": "42239.io",
      "bytes": 2616862,
      "sha256": "fbe46eea36d95e77779475fd5f463b8b9fa43c6f3f98806643ba02fca696d68f",
      "origin": "42239.io"
    },
    {
      "path": "42239.mpd",
      "bytes": 543572,
      "sha256": "a0c3ca1e813d8b5be39756d505d96c961e703d4dc099eff1860fe84c50441071",
      "origin": "model.ldr"
    },
    {
      "path": "custom/7655.dat",
      "bytes": 457765,
      "sha256": "7ea9779ab708a68ec6a1c5efeff6884e7f073d21e7d3a8296115ec7cc2dd9820",
      "origin": "CustomParts/7655.dat"
    },
    {
      "path": "custom/7683.dat",
      "bytes": 824585,
      "sha256": "95272eb3d530cdfac569165e440b69b5c6bc0b9065734c5ba51fc23388111b9c",
      "origin": "CustomParts/7683.dat"
    },
    {
      "path": "custom/103479c01-3.dat",
      "bytes": 5270345,
      "sha256": "404a1ec8942ce84c8a2730a23baa67e12367d0510d64cce6737d62b5bcdae1c6",
      "origin": "CustomParts/103479c01-3.dat"
    },
    {
      "path": "custom/69790.dat",
      "bytes": 377420,
      "sha256": "3a96c2e174d7859f31bf571bfc2a80d159a9532810521e57546db445dc795ade",
      "origin": "model2.ldr#69790.dat",
      "modifications": "Extracted from Studio embedded geometry; inherited surface/edge colors -1/-2 converted to standard LDraw16/24."
    },
    {
      "path": "custom/7101.dat",
      "bytes": 1156,
      "sha256": "f18fff7a161ea1268f017f1f36899a7b8e7462fad802e1b7fbc69d098c990c9a",
      "origin": "model2.ldr#7101.dat",
      "modifications": "Extracted from Studio embedded geometry; inherited surface/edge colors -1/-2 converted to standard LDraw16/24."
    },
    {
      "path": "custom/bl_7973.dat",
      "bytes": 69218,
      "sha256": "25aeba279450f846d805ecb6394268c76cfa044f4e3135f6403206a77f740aa5",
      "origin": "model2.ldr#7973.dat",
      "modifications": "Extracted from Studio embedded geometry; inherited surface/edge colors -1/-2 converted to standard LDraw16/24. Studio7973.dat retained under authored bl_7973.dat alias to avoid collision with an unrelated official part."
    },
    {
      "path": "custom/s/7101s01.dat",
      "bytes": 2353,
      "sha256": "c0bc0f0d90e26a351155ed4f8d7820f0af4ada2b50dc55697ea1605ad4f30129",
      "origin": "model2.ldr#s/7101s01.dat",
      "modifications": "Extracted from Studio embedded geometry; inherited surface/edge colors -1/-2 converted to standard LDraw16/24."
    },
    {
      "path": "custom/s/7101s02.dat",
      "bytes": 7906,
      "sha256": "15fe4164a9cb02296b5dff9ecb9d29c972f6353716642c79d94dea5c8020edcd",
      "origin": "model2.ldr#s/7101s02.dat",
      "modifications": "Extracted from Studio embedded geometry; inherited surface/edge colors -1/-2 converted to standard LDraw16/24."
    },
    {
      "path": "custom/s/71682s03.dat",
      "bytes": 4491,
      "sha256": "0ac5e8a2dc47f3142e7e1c8a0353ebb9fe5045c0e6490c786d67a21421f53fcb",
      "origin": "model2.ldr#s/71682s03.dat",
      "modifications": "Extracted from Studio embedded geometry; inherited surface/edge colors -1/-2 converted to standard LDraw16/24."
    }
  ]
}
```
